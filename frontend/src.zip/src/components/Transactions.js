import React, { useState } from 'react';
import { useTransaction } from '../context/TransactionContext';
import { FiEdit, FiTrash2, FiFilter, FiX, FiPlus } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import moment from 'moment';
import EditTransactionModal from './EditTransactionModal';

const Transactions = () => {
  const { transactions, loading, filters, setFilters, deleteTransaction } = useTransaction();
  const [showFilters, setShowFilters] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const resetFilters = () => {
    setFilters({
      month: moment().month() + 1,
      year: moment().year(),
      category: '',
      type: ''
    });
  };

  const handleEdit = (transaction) => {
    setEditingTransaction(transaction);
    setShowEditModal(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this transaction?')) {
      await deleteTransaction(id);
    }
  };

  const closeEditModal = () => {
    setShowEditModal(false);
    setEditingTransaction(null);
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Food & Dining': '🍽️',
      'Transportation': '🚗',
      'Shopping': '🛍️',
      'Entertainment': '🎬',
      'Bills & Utilities': '💡',
      'Healthcare': '🏥',
      'Education': '📚',
      'Salary': '💰',
      'Freelance': '💼',
      'Investment': '📈',
      'Gift': '🎁'
    };
    return icons[category] || '📊';
  };

  const formatAmount = (amount, type) => {
    const formatted = parseFloat(amount).toFixed(2);
    return type === 'income' ? `+₹${formatted}` : `-₹${formatted}`;
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', color: 'var(--primary-color)' }}>
          Transactions
        </h1>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="btn btn-outline"
          >
            <FiFilter />
            Filters
          </button>
          <Link to="/add" className="btn btn-primary">
            <FiPlus />
            Add Transaction
          </Link>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="card" style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h3>Filter Transactions</h3>
            <button
              onClick={() => setShowFilters(false)}
              className="btn btn-outline"
              style={{ padding: '0.5rem' }}
            >
              <FiX />
            </button>
          </div>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Month</label>
              <select
                name="month"
                className="form-select"
                value={filters.month}
                onChange={handleFilterChange}
              >
                {Array.from({ length: 12 }, (_, i) => i + 1).map(month => (
                  <option key={month} value={month}>
                    {moment(`${filters.year}-${month}-01`).format('MMMM')}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Year</label>
              <select
                name="year"
                className="form-select"
                value={filters.year}
                onChange={handleFilterChange}
              >
                {Array.from({ length: 5 }, (_, i) => moment().year() - 2 + i).map(year => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Type</label>
              <select
                name="type"
                className="form-select"
                value={filters.type}
                onChange={handleFilterChange}
              >
                <option value="">All Types</option>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Category</label>
              <select
                name="category"
                className="form-select"
                value={filters.category}
                onChange={handleFilterChange}
              >
                <option value="">All Categories</option>
                <option value="Food & Dining">Food & Dining</option>
                <option value="Transportation">Transportation</option>
                <option value="Shopping">Shopping</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Bills & Utilities">Bills & Utilities</option>
                <option value="Healthcare">Healthcare</option>
                <option value="Education">Education</option>
                <option value="Salary">Salary</option>
                <option value="Freelance">Freelance</option>
                <option value="Investment">Investment</option>
                <option value="Gift">Gift</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div style={{ marginTop: '1rem' }}>
            <button onClick={resetFilters} className="btn btn-outline">
              Reset Filters
            </button>
          </div>
        </div>
      )}

      {/* Transactions List */}
      <div className="card">
        <h3 style={{ marginBottom: '1rem' }}>
          {transactions.length} Transaction{transactions.length !== 1 ? 's' : ''}
        </h3>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '2rem' }}>
            Loading transactions...
          </div>
        ) : transactions.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>
            <p>No transactions found for the selected filters.</p>
            <Link to="/add" className="btn btn-primary" style={{ marginTop: '1rem' }}>
              <FiPlus />
              Add Your First Transaction
            </Link>
          </div>
        ) : (
          <div>
            {transactions.map(transaction => (
              <div key={transaction._id} className="transaction-item">
                <div className="transaction-info">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '1.5rem' }}>
                      {getCategoryIcon(transaction.category)}
                    </span>
                    <div>
                      <div className="transaction-title">{transaction.title}</div>
                      <div className="transaction-meta">
                        {transaction.category} • {moment(transaction.date).format('MMM DD, YYYY')}
                        {transaction.description && ` • ${transaction.description}`}
                      </div>
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div className={`transaction-amount ${transaction.type}`}>
                    {formatAmount(transaction.amount, transaction.type)}
                  </div>
                  
                  <div className="transaction-actions">
                    <button
                      onClick={() => handleEdit(transaction)}
                      className="btn btn-outline"
                      style={{ padding: '0.5rem' }}
                      title="Edit"
                    >
                      <FiEdit />
                    </button>
                    <button
                      onClick={() => handleDelete(transaction._id)}
                      className="btn btn-danger"
                      style={{ padding: '0.5rem' }}
                      title="Delete"
                    >
                      <FiTrash2 />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Edit Transaction Modal */}
      {showEditModal && editingTransaction && (
        <EditTransactionModal
          transaction={editingTransaction}
          onClose={closeEditModal}
          isOpen={showEditModal}
        />
      )}
    </div>
  );
};

export default Transactions;
